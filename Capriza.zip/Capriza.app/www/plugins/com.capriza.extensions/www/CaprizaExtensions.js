cordova.define("com.capriza.extensions.CaprizaExtensions", function(require, exports, module) { var exec = require('cordova/exec');

exports.echo = function (message, success, error) {
    exec(success, error, "CaprizaExtensions", "echo", [message]);
};
exports.getCookie = function (domain, name, path, success, error) {
    if (typeof path == "function") {
        error = success;
        success = path;
        path = "/";
    }

    exec(success, error, "CaprizaExtensions", "getCookie", [domain, name, path]);
};

exports.showLoading = function (message, title) {
    message = message || "";
    title = title || "";
    exec(null, null, "CaprizaExtensions", "showLoading", [message, title]);
};

exports.hideLoading = function () {
    exec(null, null, "CaprizaExtensions", "hideLoading", []);
};



});
